<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version = 2016052300;
$plugin->requires = 2016052300;        // Requires this Moodle version
$plugin->component = 'block_admin_presets';
$plugin->release = '1.31.0 (Build: 2016052300)';
$plugin->cron     = 0;
$plugin->maturity = MATURITY_STABLE;
